# Реферы

## нравится
### это то на что бы я опирался
- https://job.ozon.ru/sklad/
- https://eda.yandex.ru/partner/rabota/
### Это то что тоже круто
- https://rabota.magnit.ru/sankt-peterburg/sklad
- https://hraliance.ru/stock
- https://sklad.job-ozon.ru/vse-goroda/rabotnik-sklada/

## не нравится
- https://rabota-sklad.moscow/
- https://rabota.r-ulybka.ru/sklad
- https://www.lobanov-logist.ru/library/352/63769/


# Progress

1 Реферы ✔️
2 Дизайн ❌
3 Верстка ❌
4 Дизайн базы данных ❌
5 Авторизация ❌
6 Бэкенд ❌
7 Фронтенд ❌
8 Тестирование ❌
9 Полировка ❌
10 Заливакинс ❌
11 Финальные тесты ❌