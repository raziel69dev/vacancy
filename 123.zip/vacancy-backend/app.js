const express = require('express')
const bodyParser =  require("body-parser");
const mysql = require('mysql2');
const cors = require('cors')
const fs = require("fs");
const fileUpload = require('express-fileupload');

// connection
const connection =  mysql.createPool({
    connectionLimit: 5,
    host: "kvnorfcr.beget.tech",
    user: "kvnorfcr_123",
    database: "kvnorfcr_123",
    password: "665566aA",
    waitForConnections: true,
    connectTimeout: 15000,
    rowsAsArray: false,
    enableKeepAlive: true,
});

const app = express();
app.use(cors())
app.use(fileUpload())
app.use(bodyParser.json({limit: '10mb'}))
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true, limit: '10mb'}));

// upload
app.post('/upload', (req, res) => {
    const path = '/uploads/' + req.files['image-upload'].name
    fs.writeFile(__dirname + path, req.files['image-upload'].data, () => {
        res.send({'filePath': path})
    });
});

// vacancies
app.post('/vacancy', function (req, res) {
    const vacancy = req.body.data
    connection.query("INSERT INTO `vacancies`(`name`, `price`, `button`, `whatToDo`, `whatToDoType`, `weAwait`, `weAwaitType`, `image`) VALUES " +
        `('${vacancy.name}','${vacancy.price}','${vacancy.button}',
        '${vacancy.whatToDo}','${vacancy.whatToDoType}','${vacancy.weAwait}','${vacancy.weAwaitType}','${vacancy.vacancyImage}')`,
        function (err, rows, fields) {
            if (err) res.send(err)
            res.send(rows)
        })
})

app.delete('/vacancy', function (req, res) {
    connection.query(`DELETE FROM \`vacancies\` WHERE \`name\` = '${req.body.name}' AND \`price\` = '${req.body.price}' AND \`whatToDo\` = '${req.body.whatToDo}'`,
        function (err, rows, fields) {
            if (err) res.send(err)
            res.send(rows)
        })
})

app.put('/vacancy', function  (req, res) {

    connection.query(`UPDATE \`vacancies\` SET \`name\` = '${req.body.data.name}', \`price\` = '${req.body.data.price}',\`whatToDo\` = '${req.body.data.whatToDo}', \`whatToDoType\` = '${req.body.data.whatToDoType}', \`weAwait\` = '${req.body.data.weAwait}',\`weAwaitType\` = '${req.body.data.weAwaitType}', \`image\` = '${req.body.data.image}'  WHERE \`name\` = '${req.body.data.oldVacancyName}';`,
        function (err, rows, fields) {
            if (err) res.send(err)
            res.send(rows)
        })
})

app.get('/vacancy', function (req, res) {
    connection.query("SELECT * FROM `vacancies` WHERE 1", (err, rows, fields) => {
        if (err) res.send(err)
        res.send(rows)
    })
})

// features
app.get('/features', function (req, res) {
    connection.query("SELECT * FROM `features` WHERE 1", (err, rows, fields) => {
        if (err) res.send('error')
        res.send(rows)
    })
})

app.post('/features', function (req, res) {
    connection.query(`INSERT INTO \`features\`(\`icon\`, \`name\`, \`items\`) VALUES ('${req.body.icon}', '${req.body.name}', '${req.body.items}')`, (err, rows, fields) => {
        if (err) res.send(err)
        res.send(rows)
    })
})

app.put('/features', function (req, res) {
    const feature = req.body
    connection.query(`UPDATE \`features\` SET \`icon\` = '${req.body.icon}', \`name\` = '${req.body.name}',\`items\` = '${req.body.items}'  WHERE \`name\` = '${req.body.oldName}'`,
        function (err, rows, fields) {
            if (err) res.send(err)
            res.send(rows)
        })
})
app.delete('/features', function (req, res) {
    connection.query(`DELETE FROM \`features\` WHERE \`icon\` = '${req.body.icon}' AND \`name\` = '${req.body.name}' AND \`items\` = '${req.body.items}'`,
        function (err, rows, fields) {
            if (err) res.send(err)
            res.send(rows)
        })
})

//faq

app.get('/faq', function (req, res) {
    connection.query("SELECT * FROM `faq` WHERE 1", (err, rows, fields) => {
        if (err) res.send(err)
        res.send(rows)
    })
})

app.post('/faq', function (req, res) {
    connection.query(`INSERT INTO \`faq\`(\`question\`, \`answer\`, \`answerType\`) VALUES ('${req.body.question}', '${req.body.answer}', '${req.body.answerType}')`, (err, rows, fields) => {
        if (err) res.send(err)
        res.send(rows)
    })
})

// app.put('/faq', function (req, res) {
//     const feature = req.body
//     connection.query(`UPDATE \`features\` SET \`icon\` = '${req.body.icon}', \`name\` = '${req.body.name}',\`items\` = '${req.body.items}'  WHERE \`name\` = '${req.body.oldName}'`,
//         function (err, rows, fields) {
//             if (err) res.send(err)
//             res.send(rows)
//         })
// })
// app.delete('/faq', function (req, res) {
//     connection.query(`DELETE FROM \`features\` WHERE \`icon\` = '${req.body.icon}' AND \`name\` = '${req.body.name}' AND \`items\` = '${req.body.items}'`,
//         function (err, rows, fields) {
//             if (err) res.send(err)
//             res.send(rows)
//         })
// })

app.listen(3001, () => {
    console.log("Server started on port: 3001");
});