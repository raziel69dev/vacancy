<template>
  <div class="row">
    <div class="features">
      <h2>
        {{ features.name }}
        <svg data-v-405505ee=""
             @click="popup.show = true"
             class="interactiveSvg" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"><path data-v-405505ee="" d="M12 8V16M8 12H16M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
      </h2>

      <div class="features_cards"
           v-if="features.cards.length > 0"
      >
        <base-features-card
            :items="card.items"
            :item="card"
            @editFeature="(emit) => {
              this.popup.show = true
              this.editableFeature = emit
            }"
            v-for="card of features.cards" >

          <template #icon>
            <img :src="card.icon" alt="">
          </template>

          <template #heading>
            {{ card.name }}
          </template>


        </base-features-card>
      </div>
    </div>

    <admin-popup
        v-if="popup.show === true"
        :settings="popup"
        :data="editableFeature"
        :type="'features'"
        @modalClose="() => {
          this.popup.show = false
          this.editableFeature = null
        }"
    />




  </div>
</template>
<script>
import {features} from "@/Stores/features.js";
import baseFeaturesCard from "@/Blocks/BaseFeaturesCard.vue";
import {getFeatures, addFeature} from "@/API/featuresController.js";
import adminPopup from "@/Popups/adminPopup.vue";

export default {
  name: 'BaseFeatures',
  components: {
    baseFeaturesCard,
    adminPopup
  },
  data() {
    return {
      features,
      addFeature,
      popup: {
        show: false
      },
      editableFeature: null,
    }
  },
  mounted() {

  }
}
</script>
<style lang="scss" scoped>
.features {
  margin-top: 40px;
  display: flex;
  flex-wrap: wrap;

  h2 {
    width: 100%;
  }

  .features_cards {
    width: 100%;
    margin-top: 20px;
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    justify-content: space-between;

    &::after {
      flex: auto;
      content: ''
    }
  }
}

@media screen and (max-width: 768px){
  .features {
    .features_cards {
      flex-wrap: wrap;
    }
  }
}
</style>