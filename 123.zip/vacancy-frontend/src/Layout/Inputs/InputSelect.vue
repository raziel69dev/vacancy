<template>
  <select v-model="data"
          @change="$emit('dataChanged', data)"
  >
    <option
        :value="vacancy.name"
        :selected="data"
        :key="vacancy"
        v-for="vacancy of vacancies">
      {{ vacancy.name }} ( до 100.000₽ в мес. )
    </option>
  </select>
</template>

<script>
import {vacancies} from "@/Stores/vacancies.js";

export default {
  name: "InputSelect.vue",
  props: {
    defaultData: {}
  },
  data() {
    return {
      data: null,
      vacancies,
    }
  },
  watch: {
    defaultData: function (newVal) {
      this.data = newVal.name
    }
  },
  mounted() {

  }
}
</script>

<style scoped>

</style>