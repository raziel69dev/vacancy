import axios from "axios";
import {api} from "@/API/api.js";
import {features} from "@/Stores/features.js";
import {vacancies} from "@/Stores/vacancies.js";

export async function getFeatures() {
    return await axios.get(api + '/features').then(result => {
        features.cards.splice(0, features.cards.length)
        for (let feature of result.data) {
            features.cards.push(feature)
        }

    }).catch(err => console.log(err))
}
export function addFeature(feature) {
    return axios.post(api + '/features', feature).then(result => {
        getFeatures()
    }).catch( err => console.log(err))
}

export function editFeature(feature) {
    return axios.put(api + '/features', feature).then(result => {
        getFeatures()
    }).catch( err => console.log(err))
}
export function deleteFeature(data) {
    axios.delete(api + '/features', {data}).then(result => {
        features.cards.splice(features.cards.findIndex(item => item === data), 1)
    })
}