import axios from "axios";
import {api} from "@/API/api.js";
import {faq} from "@/Stores/faq.js";

export function getFaq() {
    axios.get(api + '/faq').then(result => {
        console.log(result.data)
        faq.items = result.data
    }).catch(err => err)
}
export function addFaq(question) {
    axios.post(api + '/faq', question).then(result => {
        console.log(result)
        getFaq()
    }).catch(err => err)
}