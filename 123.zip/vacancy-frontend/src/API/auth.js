
function checkAdmin() {
    if (localStorage.getItem('token')) {
        return true
    } else {
        return false
    }


}

export const isAdmin = checkAdmin();