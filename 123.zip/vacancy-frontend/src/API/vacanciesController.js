import {api} from "@/API/api.js";
import axios from "axios";
import {vacancies} from "@/Stores/vacancies.js";


export async function vacanciesController() {
    await axios.get(api + '/vacancy').then(result => {
        vacancies.splice(0, vacancies.length)
        for (let vacancy of result.data) {
            vacancies.push(vacancy)
        }
    }).catch(err => err)
}

export function addVacancy(data) {
    axios.post(api + '/vacancy', {data}).then(result => vacancies.push(data)).catch(err => err)
}

export function deleteVacancy(data) {
    axios.delete(api + '/vacancy', {data}).then(result => {
        vacancies.splice(vacancies.findIndex(item => item === data), 1)
    })
}

export function editVacancy(data) {
    axios.put(api + '/vacancy', {data}).then(result => result).catch(err => err)
}