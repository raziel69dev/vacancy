import {reactive} from "vue";
import videoSrc from './../Assets/IMG_0737.webm'

export const video = reactive({
    path: videoSrc
})