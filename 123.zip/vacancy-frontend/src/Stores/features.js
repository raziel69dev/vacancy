import {reactive} from "vue";
import rubleIcon from './../Assets/icons/ruble.svg'
import busIcon from './../Assets/icons/bus.svg'
import certIcon from './../Assets/icons/cert.svg'

export const features = reactive({
    name: 'Преимущества работы в нашей компании',
    cards: []
})