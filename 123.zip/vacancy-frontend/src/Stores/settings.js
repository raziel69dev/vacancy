import {reactive} from "vue";

export const settings = reactive({
    phone: '8 (495) 645-79-85',
    bannerImage: ''
})