import {reactive} from "vue";
import rich from './../Assets/images/rich.png'
import komp from './../Assets/images/komp.png'
import controller from './../Assets/images/controller.png'
import klad from './../Assets/images/klad.png'
import market from './../Assets/images/market.png'

export const vacancies = reactive([])