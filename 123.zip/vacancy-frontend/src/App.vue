<script>
import BaseHeader from './Layout/BaseHeader.vue';
import HeroBanner from "@/Components/HeroBanner.vue";
import BaseSeparator from "@/Layout/BaseSeparator.vue";
import BaseVacancies from "@/Layout/BaseVacancies.vue";
import BaseVacancyItem from "@/Blocks/BaseVacancyItem.vue";
import {vacancies} from "@/Stores/vacancies.js";
import BaseForm from "@/Layout/BaseForm.vue";
import BaseVideo from "@/Layout/BaseVideo.vue";
import BaseFeatures from "@/Layout/BaseFeatures.vue";
import BaseOurWorks from "@/Layout/BaseOurWorks.vue";
import BaseCarousel from "@/Layout/BaseCarousel.vue";
import BaseFaq from "@/Layout/BaseFaq.vue";
import BaseFooter from "@/Layout/BaseFooter.vue";
import {vacanciesController} from "@/API/vacanciesController.js";
import {features} from "@/Stores/features.js";
import {getFeatures} from "@/API/featuresController.js";


export default {
  components: {
    BaseFooter,
    BaseFaq,
    BaseCarousel,
    BaseFeatures,
    BaseVideo,
    BaseForm,
    BaseHeader,
    HeroBanner,
    BaseSeparator,
    BaseVacancyItem,
    BaseVacancies,
    BaseOurWorks
  },
  data () {
    return {
      vacancy: null,
      vacancies,
      features
    }
  },
  methods: {
    vacancyChanged (vacancy) {
      this.vacancy = vacancy
      // this.$refs.vacancyItem.scrollIntoView({block: "start",  behavior: "smooth" });
    },
    setDefaultVacancy(vacancyName) {

      vacancies.find(item => item.name === vacancyName) ? this.vacancy = vacancies.find(item => item.name === vacancyName) : this.vacancy = vacancies.find(item => item.name === vacancies[0].name)
    },

  },
  mounted() {
    vacanciesController().then(result => {
      let urlParams = new URLSearchParams(window.location.search);
      urlParams.has('vacancy') ? this.setDefaultVacancy(urlParams.get('vacancy')) : this.setDefaultVacancy(vacancies[0].name)
    })
    getFeatures()
  }

}
</script>

<template>
  <BaseHeader />
  <HeroBanner />
  <BaseSeparator />

  <BaseVacancies

      id="vacancies"
      ref="vacancies"
      :active="vacancy"
      @vacancyChanged="emit => vacancyChanged(emit)"
  />

  <BaseVacancyItem
      v-if="vacancies.length > 0"
      :data="vacancy"

  />

  <BaseForm
      v-if="vacancies.length > 0"
      id="form"
      :data="vacancy"
  />

  <BaseVideo />
  <BaseFeatures  />
  <BaseOurWorks />
  <BaseCarousel />
  <BaseFaq />
  <BaseFooter/>

</template>

