<template>
  <h4 class="heading">Загрузить видео</h4>

  <div class="form">
    <div class="input-control">
      <input type="file" @change="e => {
          uploadImage(e.target.files[0]).then(result => {

          }) }">
    </div>
  </div>
</template>
<script>
import {uploadImage} from "@/API/uploadImage.js";
export default {
  name: 'uploadVideo',
  data() {
    return {
      uploadImage
    }
  }
}
</script>
<style lang="scss" scoped>
.form {
  width: 100%;
  input {
    width: 100%;
    box-sizing: border-box;
  }
}
</style>

