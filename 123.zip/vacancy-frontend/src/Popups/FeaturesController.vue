<template>
  <div class="heading">
    <h4>Преимущества</h4>
    <div class="close" @click="$emit('closeModal', true)">
      <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M13 1L1 13M1 1L13 13" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>

    </div>
  </div>

  <div class="form">
    <div class="input-control">
      <label for="name">Название карточки</label>
      <input type="text" id="name" v-model="feature.name">
    </div>
    <div class="input-control">
      <label>Список преимуществ</label>
      <span class="help">
            Разделителем будет точка с запятой: мы хотим что бы вы ...; мы хотим что бы вы ...; итд
          </span>
      <textarea v-model="feature.items"/>

    </div>

    <div class="input-control">
      <img :src="feature.icon" alt="" v-if="feature.icon">
      <div class="edit" v-if="feature.icon" @click="feature.icon = null">
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M10 19H19M1.00003 19H2.67457C3.16376 19 3.40835 19 3.63852 18.9447C3.84259 18.8957 4.03768 18.8149 4.21663 18.7053C4.41846 18.5816 4.59141 18.4086 4.93732 18.0627L17.5001 5.49998C18.3285 4.67156 18.3285 3.32841 17.5001 2.49998C16.6716 1.67156 15.3285 1.67156 14.5001 2.49998L1.93729 15.0627C1.59139 15.4086 1.41843 15.5816 1.29475 15.7834C1.18509 15.9624 1.10428 16.1574 1.05529 16.3615C1.00003 16.5917 1.00003 16.8363 1.00003 17.3255V19Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        Заменить изображение
      </div>
      <input type="file" v-else @change="e => {
        uploadImage(e.target.files[0]).then(result => {
          this.feature.icon = result.data.filePath
        })
          }">
    </div>
    <div class="button">
      <button-primary
          :buttonSize="'long'"
          @buttonPressed="!$props.data ? addFeature(this.feature) : editFeature(this.feature)"
      >
        <template #button-text>
          Добавить преимущество
        </template>
      </button-primary>
    </div>
    {{ feature }}
  </div>
</template>
<script>
import buttonPrimary from "@/Layout/Buttons/ButtonPrimary.vue";
import {uploadImage} from "@/API/uploadImage.js";
import {addFeature, editFeature} from "@/API/featuresController.js";

export default {
  name: 'featuresController',
  props: {
    data: {}
  },
  components: {
    buttonPrimary
  },
  data() {
    return {
      feature: {},
      oldName: null,
      addFeature,
      editFeature,
      uploadImage
    }
  },
  mounted() {
    if (this.$props.data) {
      this.feature = this.$props.data
      this.feature.oldName = this.$props.data.name
    }
  }
}
</script>
<style lang="scss" scoped>
.form {
  .input-control {
    display: flex;
    flex-wrap: wrap;
    margin-bottom: 10px;

    .edit {
      cursor: pointer;
      font-family: "IBM Plex Sans";
      svg {
        width: 15px;
        height: 15px;
        path {
          stroke-width: 1px;
        }

      }
    }

    .help {
      color: var(--black, #737373);
      font-family: "IBM Plex Sans";
      font-size: 12px;
      font-style: normal;
      font-weight: 400;
      line-height: normal;
    }
    input {
      width: 100%;
    }
    label {
      width: 100%;

    }
  }
  .typeSelect {
    display: flex;
    align-items: center;
    gap: 20px;
  }
}
.heading {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.button {
  width: 100%;

  margin-top: 20px;
}
</style>