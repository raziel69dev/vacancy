<template>

</template>

<script>
export default {
  name: "BasePage.vue"
}
</script>

<style scoped>

</style>