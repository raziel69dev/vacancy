<template>

  <div class="feature_item">
    <div class="icon">
      <slot name="icon" />

      <span class="delete" >
        <svg width="20" @click="$emit('editFeature', $props.item)" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M10 19H19M1.00003 19H2.67457C3.16376 19 3.40835 19 3.63852 18.9447C3.84259 18.8957 4.03768 18.8149 4.21663 18.7053C4.41846 18.5816 4.59141 18.4086 4.93732 18.0627L17.5001 5.49998C18.3285 4.67156 18.3285 3.32841 17.5001 2.49998C16.6716 1.67156 15.3285 1.67156 14.5001 2.49998L1.93729 15.0627C1.59139 15.4086 1.41843 15.5816 1.29475 15.7834C1.18509 15.9624 1.10428 16.1574 1.05529 16.3615C1.00003 16.5917 1.00003 16.8363 1.00003 17.3255V19Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <svg width="20" @click="deleteFeature($props.item)" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M7 1H13M1 4H19M17 4L16.2987 14.5193C16.1935 16.0975 16.1409 16.8867 15.8 17.485C15.4999 18.0118 15.0472 18.4353 14.5017 18.6997C13.882 19 13.0911 19 11.5093 19H8.49065C6.90891 19 6.11803 19 5.49834 18.6997C4.95276 18.4353 4.50009 18.0118 4.19998 17.485C3.85911 16.8867 3.8065 16.0975 3.70129 14.5193L3 4" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>

      </span>
    </div>
    <div class="heading">
      <slot name="heading" />
    </div>
    <div class="description">
      <ul class="description_item" >
        <li v-for="item of $props.items.split(';')">{{ item }}</li>
      </ul>
    </div>
  </div>

</template>

<script>
import {deleteFeature} from "@/API/featuresController.js";


export default {
  name: "BaseFeaturesCard.vue",
  props: {
    items: [],
    item: {}
  },
  data() {
    return {
      items: [],
      deleteFeature
    }
  },
  watch: {
    items: function (newVal, oldVal) {

    }
  },

  components: {

  },

  methods: {

  },

  mounted() {

  }

}
</script>

<style scoped lang="scss">
.feature_item {
  border-radius: 10px;
  background: #FFF;
  width: 29%;
  padding: 15px;

  .heading {
    color: var(--black, #000);
    font-family: "IBM Plex Sans";
    font-size: 20px;
    font-style: normal;
    font-weight: 600;
    line-height: 20px; /* 100% */
    margin-bottom: 15px;
    margin-top: 15px;
  }

  .description {
    .description_item {
      padding-left: 20px;
      color: var(--black, #000);
      font-family: "IBM Plex Sans";
      font-size: 14px;
      font-style: normal;
      font-weight: 400;
      line-height: normal;
    }
  }
  .icon {
    display: flex;
    justify-content: space-between;
  }

  transition: .15s ease;
  cursor: default;
  &:hover {
    transform: scale(1.02);
  }
}
.delete {
  display: flex;
  gap: 10px;

  svg {
    cursor: pointer;
    path{
      transition: .3s ease;
    }

    &:hover {
      path {
        stroke: #b20931;
      }
    }
  }
}
@media screen and (max-width: 768px){
  .feature_item {
    width: 100%;
  }
}
</style>